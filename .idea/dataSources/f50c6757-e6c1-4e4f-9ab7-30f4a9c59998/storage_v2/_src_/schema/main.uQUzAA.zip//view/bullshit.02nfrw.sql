CREATE VIEW bullshit as select name from cities where name like ('% City');

